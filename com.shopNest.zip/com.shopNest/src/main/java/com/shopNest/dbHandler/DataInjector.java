package com.shopNest.dbHandler;

import java.sql.*;

import javax.servlet.annotation.WebServlet;


public class DataInjector {
	public static String addCustomer(String uname,String mail,String pass,String gender,String address) {
		String driver="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String userName="system";
		String password="system";
		String sql= "INSERT INTO CUSTOMERS VALUES(?,?,?,?,?)";
		String status="";
		try {
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url, userName, password);
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1, uname);
			ps.setString(2, mail);
			ps.setString(3, pass);
			ps.setString(4, gender);
			ps.setString(5, address);
			
			ps.executeUpdate();
			
			status="success";
			
		}catch(Exception ex) {
			System.out.println("Problem in adding customer");
			ex.printStackTrace();
			status="fail";
			
		}
		//finally {
			return status;
		//}
				
	}    
}
